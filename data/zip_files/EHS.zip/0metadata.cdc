@UTF8
Title:	CHILDES English EHS Corpus
Creator:	Snow, Catherine
Creator:	Aboud, Catherine
Creator:	Rowe, Meredith
Language:	eng
Description:	parent–child interaction during free play session in two families with working parents and a child in day care
Date:		2025
Country:	United States

DOI:	10.21415/ESE3-M119
