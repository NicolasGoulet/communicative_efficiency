Title:	PhonBank Clinical English Cummings Corpus	
Creator:	Cummings, Alycia
Language:	eng
Description:	30 children with speech sound disorders
Date:		2016-05-12
Country:	United States
DOI:	doi:10.21415/T5MG6R
