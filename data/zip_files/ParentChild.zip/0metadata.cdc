Title:	CHILDES Clinical English Feldman Corpus: Parent-Child
Creator:	Feldman, Heidi
Language:	eng
Description:	longitudinal study that examines parent-child interactions in children suffering perinatal brain injury and control children
Date:		2004-04-05
Country:	United States
DOI:	doi:10.21415/T5GK55
